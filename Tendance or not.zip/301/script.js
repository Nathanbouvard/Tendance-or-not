document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.clickable-image').forEach(image => {
        image.addEventListener('click', () => {
            const modalImage = document.getElementById('modalImage');
            const modalDescription = document.getElementById('modalDescription');
            const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));

            modalImage.src = image.src;
            modalImage.alt = image.alt;
            modalDescription.textContent = image.dataset.description;

            imageModal.show();
        });
    });
});